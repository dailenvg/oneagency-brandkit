ONE Agency brand kit
Brand kit v1.1 · Updated 2026-11-17

Digital only: RGB colour, px sizes, SVG/PNG/JPG/WebP, web fonts, MP4/GIF and HTML5.
File names follow one-agency_[asset]_[variant]_[size].[ext].

Folders
  logos/      stacked, horizontal and icon lockups (on dark, on light, white, ink), favicons, social images
  colour/     the live site's colour tokens as CSS and JSON
  fonts/      Geist, Lato and Metal (TTF and WOFF2) with their licences
  elements/   signature devices, patterns and illustrations (on dark and on light), the Möbius loop stills,
              halo, glow field, laurel, CTA buttons, proof bar, award badge, icons
  illustrations/, textures/  glass illustrations (AI-generated in Magnific) and textures (made in code)
  references/ the nine reference ads the glass and texture style comes from
  vendor/ciq/ credit for the Möbius loop on the kit site (ConversionIQ's key visual, used as supplied)
  templates/  ad templates and sample ads (editable versions live in Magnific)
  imagery/    starter image library, AI-generated in Magnific (no real people or clients); stand-ins until real client work exists
  motion/     one-motion.js (the motion runtime), HTML5 ad sources, and exports (MP4, GIF, end frames, HTML5 ZIPs)
  copy/       the copy bank (Markdown and JSON)

Licences
  Geist, Lato and Metal are under the SIL Open Font License 1.1 (see fonts/*_ofl.txt).
  Logos and all other brand assets belong to ONE Agency, LLC. Use them only for ONE Agency work.
  The 2026 ARDY Award belongs to ConversionIQ.ai; say so wherever it appears.
  The Möbius loop on the kit site (ciq-loop.js) is ConversionIQ's key visual, used as supplied; it is not part of
  this kit.

Sources
  Colour: https://oneagency.com/assets/css/home.bundle.css?v=746d4bae1d (pulled 2026-11-17)
  Logo: https://oneagency.com/assets/img/one-agency-logo.svg
  Proof figures 10M+, $100M+, 7B+, 450K+: as published on oneagency.com, November 2026.

Full kit only
  Illustrations come as PNG only here, to keep this ZIP under 100 MiB. Their WebP versions are in
  one-agency_kit_glass.zip and on the site.
  The Möbius loop stills (elements/mobius/) are in one-agency_kit_elements.zip and on the site, not here.
